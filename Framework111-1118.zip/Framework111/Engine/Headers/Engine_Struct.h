#pragma once
#ifndef __ENGINE_STRUCT_H__

struct Vertex
{
	Vertex() {}
	Vertex(float _x, float _y, float _z)
	{
		x = _x;
		y = _y;
		z = _z;
	}
	float x, y, z;
	static const DWORD FVF ;
};

struct ColorVertex
{
	float x, y, z;
	D3DCOLOR color;
	static const DWORD FVF = D3DFVF_XYZ | D3DFVF_DIFFUSE;
};

#define __ENGINE_STRUCT_H__
#endif