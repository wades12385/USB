#include "stdafx.h"
#include "..\Headers\Stage.h"


CStage::CStage(LPDIRECT3DDEVICE9 pDevice)
	: CScene(pDevice)
{
}

HRESULT CStage::ReadyScene()
{
	CScene::ReadyScene();

	
	//m_pDevice->CreateVertexBuffer(3 * sizeof(ColorVertex) , D3DUSAGE_WRITEONLY
	//	, CUSTOM_FVF,D3DPOOL_MANAGED, &m_iTriangle, 0);
	//ColorVertex* pVertices;
	//m_iTriangle->Lock(0, 0, (void**)&pVertices, 0);
	//pVertices[0] = { -1.f, 0.0f, 2.0f, D3DCOLOR_XRGB(255, 0, 0) };
	//pVertices[1] = { 0.f, 1.f, 2.0f, D3DCOLOR_XRGB(0, 255, 0) };
	//pVertices[2] = { 1.f, 0.0f, 2.0f, D3DCOLOR_XRGB(0, 0, 255) };
	//m_iTriangle->Unlock();


	m_pDevice->CreateVertexBuffer(3* sizeof(ColorVertex), D3DUSAGE_WRITEONLY
		, CUSTOM_FVF, D3DPOOL_MANAGED, &m_iTriangle, 0);
	ColorVertex* pVertices;
	m_iTriangle->Lock(0, 0, (void**)&pVertices, 0);
	pVertices[0] = { 0, 0, 2.0f, D3DCOLOR_XRGB(255, 0, 0) };
	pVertices[1] = { 1.f, 1.f,  2.0f, D3DCOLOR_XRGB(0, 255, 0) };
	pVertices[2] = { 0, -1.0f, 3.0f, D3DCOLOR_XRGB(0, 144, 255) };

	m_iTriangle->Unlock();
	m_vCamera = _vector(0, 0, 0);
	m_fAngleZ = 0.f;
	D3DXMATRIX proj;
	D3DXMatrixPerspectiveFovLH(
		&proj, //�ƿ�ǲ �� 
		D3DX_PI * 0.4f,//�þ߰��� �������� (����)
		1,//��Ⱦ��
		1.0f, // ����� �������� �Ÿ� 
		500.0f);//�� ������ �Ÿ� 
	m_pDevice->SetTransform(D3DTS_PROJECTION, &proj);

	m_pDevice->SetRenderState(D3DRS_LIGHTING, false);
	return S_OK;
}

_uint CStage::UpdateScene()
{
	CScene::UpdateScene();

	if (GetAsyncKeyState('Z') & 0x0001)
		m_fAngleZ += 1.5f;
	if (GetAsyncKeyState('X') & 0x0001)
		m_fAngleZ -= 1.5f;

	if (GetAsyncKeyState('A') & 0x0001)
		m_fAngleY += 1.5f;
	if (GetAsyncKeyState('S') & 0x0001)
		m_fAngleY -= 1.5f;


	if (GetAsyncKeyState(VK_LEFT) & 0x0001)
		m_vCamera.x += 1.5f;
	if (GetAsyncKeyState(VK_RIGHT) & 0x0001)
		m_vCamera.x -= 1.5f;

	if (GetAsyncKeyState(VK_UP) & 0x0001)
		m_vCamera.z += 1.5f;
	if (GetAsyncKeyState(VK_DOWN) & 0x0001)
		m_vCamera.z -= 1.5f;


	_matrix matRotY, matRotZ, matTrans;
	D3DXMatrixRotationY(&matRotY, D3DXToRadian(m_fAngleY));
	D3DXMatrixRotationZ(&matRotZ, D3DXToRadian(m_fAngleZ));
	D3DXMatrixTranslation(&matTrans, m_vCamera.x, m_vCamera.y, m_vCamera.z);
	m_matWorld = matRotY * matRotZ * matTrans;
	return _uint();
}

_uint CStage::LateUpdateScene()
{
	CScene::LateUpdateScene();

	return _uint();
}

_uint CStage::RenderScene()
{
	m_pDevice->SetFVF(CUSTOM_FVF);
	m_pDevice->SetStreamSource(0, m_iTriangle, 0, sizeof(ColorVertex));

	m_pDevice->SetTransform(D3DTS_WORLD, &m_matWorld);
	m_pDevice->SetRenderState(D3DRS_SHADEMODE, D3DSHADE_GOURAUD);
	//m_pDevice->SetRenderState(D3DRS_FILLMODE, D3DFILL_WIREFRAME);

	m_pDevice->DrawPrimitive(D3DPT_TRIANGLELIST, 0, 1);

	return _uint();
}

CStage * CStage::Create(LPDIRECT3DDEVICE9 pDevice)
{
	if (nullptr == pDevice)
		return nullptr;

	CStage* pInstance = new CStage(pDevice);
	if (FAILED(pInstance->ReadyScene()))
	{
		PRINT_LOG(L"Error", L"Failed To Create CStage");
		SafeRelease(pInstance);
	}

	return pInstance;
}

void CStage::Free()
{
	SafeRelease(m_iTriangle);
	CScene::Free();
}
