#pragma once
#ifndef __STAGE_H__

#include "Scene.h"

USING(Engine)
class CStage : public CScene
{
private:
	explicit CStage(LPDIRECT3DDEVICE9 pDevice);
	virtual ~CStage() = default;

public:
	virtual HRESULT ReadyScene() override;
	virtual _uint UpdateScene() override;
	virtual _uint LateUpdateScene() override;
	virtual _uint RenderScene() override;
public:
	static CStage* Create(LPDIRECT3DDEVICE9 pDevice);
	virtual void Free() override;
private:
	IDirect3DVertexBuffer9* m_iTriangle = 0;
	D3DXMATRIX m_matWorld;
	float m_fAngleZ = 0.f;
	float m_fAngleY = 0.f;
	_vector m_vCamera;

};

#define __STAGE_H__
#endif
