#pragma once

#ifndef __CLIENT_EXTERN_H__

extern HWND g_hWnd;

#define __CLIENT_EXTERN_H__
#endif