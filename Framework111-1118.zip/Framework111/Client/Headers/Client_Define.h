#pragma once

#ifndef __CLIENT_DEFINE_H__

#define WINCX 800
#define WINCY 600

#define __CLIENT_DEFINE_H__
#define CUSTOM_FVF D3DFVF_XYZ | D3DFVF_DIFFUSE | D3DFVF_TEX1

#endif